function check2()
{
  
  var ques1= document.quiz02.ques1.value;
   if(ques1 == "")
    {
      alert("You Skipped Q1");
     var ques1= document.quiz02.ques1.value;
            return false;
    } 
  
  var ques2= document.quiz02.ques2.value;
   if(ques2 == "")
    {
      alert("You Skipped Q2");
      var ques2= document.quiz02.ques2.value;
          return false;
    } 
   
  var ques3= document.quiz02.ques3.value;
   if(ques3 == "")
    {
      alert("You Skipped Q3");
      var ques3= document.quiz02.ques3.value;
           return false;
    } 
  var ques4= document.quiz02.ques4.value;
    if(ques4 == "")
    {
      alert("You Skipped Q4");
      var ques4= document.quiz02.ques4.value;
    return false;
    } 
  var ques5= document.quiz02.ques5.value;
    if(ques5 == "")
    {
      alert("You Skipped Q5");
       var ques5= document.quiz02.ques5.value;
      return false;
    } 
  var ques6= document.quiz02.ques6.value;
   if(ques6 == "")
    {
      alert("You Skipped Q6");
       var ques6= document.quiz02.ques6.value;
           return false;
    } 
  var ques7= document.quiz02.ques7.value;
    if(ques7 == "")
    {
      alert("You Skipped Q7");
       var ques7= document.quiz02.ques7.value;
           return false;
    }
  var ques8= document.quiz02.ques8.value;
    if(ques8 == "")
    {
      alert("You Skipped Q8");
      var ques8= document.quiz02.ques8.value;
          return false;
    }
  var ques9= document.quiz02.ques9.value;
    if(ques9 == "")
    {
      alert("You Skipped Q9");
       var ques9= document.quiz02.ques9.value;
          return false;
    } 
  var ques10= document.quiz02.ques10.value;
       if(ques10 == "")
    {
      alert("You Skipped Q10");
      var ques10= document.quiz02.ques10.value;
        return false;
    }
 var count2=0;
 var total2=10;
   
   if(ques1 == "Chaitya")
    {
      count2++;
    } 
   
   if(ques2 == "Ajmer")
    {
      count2++;
    }
     
   if(ques3 == "Ramadas")
    {
      count2++;
    }
   
   if(ques4 == "Shershah Suri")
    {
      count2++;
    }
    
   if(ques5 == "Pallavas")
    {
      count2++;
    }
     
   if(ques6 == "Shershah Suri")
    {
      count2++;
    }
    
  if(ques7 == "Shah Jahan")
    {
      count2++;
    }
   
  if(ques8 == "Golkonda")
    {
      count2++;
    }
    
  if(ques9 == "Ghori's bodyguard")
    {
      count2++;
    }
  
  if(ques10 == "Vedic civilization")
    {
      count2++;
    }


localStorage.setItem("myval12", count2);
}