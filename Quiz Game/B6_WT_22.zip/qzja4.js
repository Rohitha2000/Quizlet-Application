function check4()
{
  
  var ques1= document.quiz04.ques1.value;
   if(ques1 == "")
    {
      alert("You Skipped Q1");
     var ques1= document.quiz04.ques1.value;
            return false;
    } 
  
  var ques2= document.quiz04.ques2.value;
   if(ques2 == "")
    {
      alert("You Skipped Q2");
      var ques2= document.quiz04.ques2.value;
          return false;
    } 
   
  var ques3= document.quiz04.ques3.value;
   if(ques3 == "")
    {
      alert("You Skipped Q3");
      var ques3= document.quiz04.ques3.value;
           return false;
    } 
  var ques4= document.quiz04.ques4.value;
    if(ques4 == "")
    {
      alert("You Skipped Q4");
      var ques4= document.quiz04.ques4.value;
    return false;
    } 
  var ques5= document.quiz04.ques5.value;
    if(ques5 == "")
    {
      alert("You Skipped Q5");
       var ques5= document.quiz04.ques5.value;
      return false;
    } 
  var ques6= document.quiz04.ques6.value;
   if(ques6 == "")
    {
      alert("You Skipped Q6");
       var ques6= document.quiz04.ques6.value;
           return false;
    } 
  var ques7= document.quiz04.ques7.value;
    if(ques7 == "")
    {
      alert("You Skipped Q7");
       var ques7= document.quiz04.ques7.value;
           return false;
    }
  var ques8= document.quiz04.ques8.value;
    if(ques8 == "")
    {
      alert("You Skipped Q8");
      var ques8= document.quiz04.ques8.value;
          return false;
    }
  var ques9= document.quiz04.ques9.value;
    if(ques9 == "")
    {
      alert("You Skipped Q9");
       var ques9= document.quiz04.ques9.value;
          return false;
    } 
  var ques10= document.quiz04.ques10.value;
       if(ques10 == "")
    {
      alert("You Skipped Q10");
      var ques10= document.quiz04.ques10.value;
        return false;
    }
 var count4=0;
 
   
   if(ques1 == "Param Vir Chakra")
    {
      count4++;
    } 
   
   if(ques2 == "Rabindranath Tagore")
    {
      count4++;
    }
     
   if(ques3 == "1961")
    {
      count4++;
    }
   
   if(ques4 == "the most conspicuous bravery or self sacrifice on land, air or sea but not in the presence of the enemy")
    {
      count4++;
    }
    
   if(ques5 == "Films")
    {
      count4++;
    }
     
   if(ques6 == "Bharat Ratna")
    {
      count4++;
    }
    
  if(ques7 == "Moorti Literacy Award")
    {
      count4++;
    }
   
  if(ques8 == "Toni Morrison")
    {
      count4++;
    }
    
  if(ques9 == "Gandhi")
    {
      count4++;
    }
  
  if(ques10 == "Magsaysay")
    {
      count4++;
    }


localStorage.setItem("myv4", count4);
}