function check()
{
  
  var ques1= document.quiz.ques1.value;
   if(ques1 == "")
    {
      alert("You Skipped Q1");
     var ques1= document.quiz.ques1.value;
            return false;
    } 
  
  var ques2= document.quiz.ques2.value;
   if(ques2 == "")
    {
      alert("You Skipped Q2");
      var ques2= document.quiz.ques2.value;
          return false;
    } 
   
  var ques3= document.quiz.ques3.value;
   if(ques3 == "")
    {
      alert("You Skipped Q3");
      var ques3= document.quiz.ques3.value;
           return false;
    } 
  var ques4= document.quiz.ques4.value;
    if(ques4 == "")
    {
      alert("You Skipped Q4");
      var ques4= document.quiz.ques4.value;
    return false;
    } 
  var ques5= document.quiz.ques5.value;
    if(ques5 == "")
    {
      alert("You Skipped Q5");
       var ques5= document.quiz.ques5.value;
      return false;
    } 
  var ques6= document.quiz.ques6.value;
   if(ques6 == "")
    {
      alert("You Skipped Q6");
       var ques6= document.quiz.ques6.value;
           return false;
    } 
  var ques7= document.quiz.ques7.value;
    if(ques7 == "")
    {
      alert("You Skipped Q7");
       var ques7= document.quiz.ques7.value;
           return false;
    }
  var ques8= document.quiz.ques8.value;
    if(ques8 == "")
    {
      alert("You Skipped Q8");
      var ques8= document.quiz.ques8.value;
          return false;
    }
  var ques9= document.quiz.ques9.value;
    if(ques9 == "")
    {
      alert("You Skipped Q9");
       var ques9= document.quiz.ques9.value;
          return false;
    } 
  var ques10= document.quiz.ques10.value;
       if(ques10 == "")
    {
      alert("You Skipped Q10");
      var ques10= document.quiz.ques10.value;
        return false;
    }
 var count=0;
 var total=10;
   
   if(ques1 == "Rafflesia")
    {
      count++;
    } 
   
   if(ques2 == "Angel falls")
    {
      count++;
    }
     
   if(ques3 == "Inland taipan")
    {
      count++;
    }
   
   if(ques4 == "Mariana trench")
    {
      count++;
    }
    
   if(ques5 == "270")
    {
      count++;
    }
     
   if(ques6 == "Curcuma longa")
    {
      count++;
    }
    
  if(ques7 == "Valdivia earthquake")
    {
      count++;
    }
   
  if(ques8 == "Tokyo")
    {
      count++;
    }
    
  if(ques9 == "Angsi glacier")
    {
      count++;
    }
  
  if(ques10 == "Salar de Uyuni")
    {
      count++;
    }


localStorage.setItem("myval", count);
}
