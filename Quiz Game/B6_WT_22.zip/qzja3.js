function check3()
{
  
  var ques1= document.quiz03.ques1.value;
   if(ques1 == "")
    {
      alert("You Skipped Q1");
     var ques1= document.quiz03.ques1.value;
            return false;
    } 
  
  var ques2= document.quiz03.ques2.value;
   if(ques2 == "")
    {
      alert("You Skipped Q2");
      var ques2= document.quiz03.ques2.value;
          return false;
    } 
   
  var ques3= document.quiz03.ques3.value;
   if(ques3 == "")
    {
      alert("You Skipped Q3");
      var ques3= document.quiz03.ques3.value;
           return false;
    } 
  var ques4= document.quiz03.ques4.value;
    if(ques4 == "")
    {
      alert("You Skipped Q4");
      var ques4= document.quiz03.ques4.value;
    return false;
    } 
  var ques5= document.quiz03.ques5.value;
    if(ques5 == "")
    {
      alert("You Skipped Q5");
       var ques5= document.quiz03.ques5.value;
      return false;
    } 
  var ques6= document.quiz03.ques6.value;
   if(ques6 == "")
    {
      alert("You Skipped Q6");
       var ques6= document.quiz03.ques6.value;
           return false;
    } 
  var ques7= document.quiz03.ques7.value;
    if(ques7 == "")
    {
      alert("You Skipped Q7");
       var ques7= document.quiz03.ques7.value;
           return false;
    }
  var ques8= document.quiz03.ques8.value;
    if(ques8 == "")
    {
      alert("You Skipped Q8");
      var ques8= document.quiz03.ques8.value;
          return false;
    }
  var ques9= document.quiz03.ques9.value;
    if(ques9 == "")
    {
      alert("You Skipped Q9");
       var ques9= document.quiz03.ques9.value;
          return false;
    } 
  var ques10= document.quiz03.ques10.value;
       if(ques10 == "")
    {
      alert("You Skipped Q10");
      var ques10= document.quiz03.ques10.value;
        return false;
    }
 var count3=0;
 
   
   if(ques1 == "Lala Amarnath")
    {
      count3++;
    } 
   
   if(ques2 == "Golf")
    {
      count3++;
    }
     
   if(ques3 == "38 inches")
    {
      count3++;
    }
   
   if(ques4 == "Boxing")
    {
      count3++;
    }
    
   if(ques5 == "Badminton")
    {
      count3++;
    }
     
   if(ques6 == "1983")
    {
      count3++;
    }
    
  if(ques7 == "Garry Kasparov")
    {
      count3++;
    }
   
  if(ques8 == "Japan")
    {
      count3++;
    }
    
  if(ques9 == "Marry kom")
    {
      count3++;
    }
  
  if(ques10 == "Rahi")
    {
      count3++;
    }


localStorage.setItem("myv3", count3);
}