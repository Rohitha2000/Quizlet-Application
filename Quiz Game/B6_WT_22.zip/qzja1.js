function check1()
{
  
  var ques1= document.quiz01.ques1.value;
   if(ques1 == "")
    {
      alert("You Skipped Q1");
     var ques1= document.quiz01.ques1.value;
            return false;
    } 
  
  var ques2= document.quiz01.ques2.value;
   if(ques2 == "")
    {
      alert("You Skipped Q2");
      var ques2= document.quiz01.ques2.value;
          return false;
    } 
   
  var ques3= document.quiz01.ques3.value;
   if(ques3 == "")
    {
      alert("You Skipped Q3");
      var ques3= document.quiz01.ques3.value;
           return false;
    } 
  var ques4= document.quiz01.ques4.value;
    if(ques4 == "")
    {
      alert("You Skipped Q4");
      var ques4= document.quiz01.ques4.value;
    return false;
    } 
  var ques5= document.quiz01.ques5.value;
    if(ques5 == "")
    {
      alert("You Skipped Q5");
       var ques5= document.quiz01.ques5.value;
      return false;
    } 
  var ques6= document.quiz01.ques6.value;
   if(ques6 == "")
    {
      alert("You Skipped Q6");
       var ques6= document.quiz01.ques6.value;
           return false;
    } 
  var ques7= document.quiz01.ques7.value;
    if(ques7 == "")
    {
      alert("You Skipped Q7");
       var ques7= document.quiz01.ques7.value;
           return false;
    }
  var ques8= document.quiz01.ques8.value;
    if(ques8 == "")
    {
      alert("You Skipped Q8");
      var ques8= document.quiz01.ques8.value;
          return false;
    }
  var ques9= document.quiz01.ques9.value;
    if(ques9 == "")
    {
      alert("You Skipped Q9");
       var ques9= document.quiz01.ques9.value;
          return false;
    } 
  var ques10= document.quiz01.ques10.value;
       if(ques10 == "")
    {
      alert("You Skipped Q10");
      var ques10= document.quiz01.ques10.value;
        return false;
    }
 var count1=0;
 var total1=10;
   
   if(ques1 == "1 trillion")
    {
      count1++;
    } 
   
   if(ques2 == "8")
    {
      count1++;
    }
     
   if(ques3 == "Bone marrow")
    {
      count1++;
    }
   
   if(ques4 == "Brain")
    {
      count1++;
    }
    
   if(ques5 == "Chronic pancreatitis")
    {
      count1++;
    }
     
   if(ques6 == "Plasma")
    {
      count1++;
    }
    
  if(ques7 == "Stem cells")
    {
      count1++;
    }
   
  if(ques8 == "3")
    {
      count1++;
    }
    
  if(ques9 == "20 feet")
    {
      count1++;
    }
  
  if(ques10 == "Stapes")
    {
      count1++;
    }


localStorage.setItem("myval11", count1);
}